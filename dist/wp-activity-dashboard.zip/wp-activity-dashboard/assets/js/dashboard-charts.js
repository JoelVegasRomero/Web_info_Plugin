// Esperar a que el DOM esté completamente cargado
document.addEventListener('DOMContentLoaded', function() {
    
    // Verificamos si los datos han sido pasados desde PHP
    if (typeof wadChartData === 'undefined') {
        console.error('No se encontraron los datos para los gráficos.');
        return;
    }

    // Colores globales para mantener un diseño coherente
    const colors = {
        primary: '#2271b1', // Azul WordPress
        secondary: '#00a32a', // Verde
        accent: '#d63638', // Rojo
        warning: '#dba617', // Amarillo
        purple: '#8224e3',
        cyan: '#00a0d2',
        gray: '#646970',
        lightGray: '#f0f0f1'
    };

    // --- 0. KPI Visitas Totales ---
    const totalViewsEl = document.getElementById('wadTotalViews');
    if (totalViewsEl) {
        // Animación sencilla de contador
        let current = 0;
        const target = wadChartData.total_views;
        const increment = Math.ceil(target / 50); // Ajusta la velocidad
        
        if (target > 0) {
            const timer = setInterval(() => {
                current += increment;
                if (current >= target) {
                    current = target;
                    clearInterval(timer);
                }
                totalViewsEl.textContent = new Intl.NumberFormat().format(current);
            }, 20);
        }
    }

    // --- NUEVO: Gráfico Top 5 Más Vistos (Barra Horizontal) ---
    const ctxMostViewed = document.getElementById('mostViewedChart');
    if (ctxMostViewed) {
        const mvLabels = wadChartData.most_viewed.map(item => {
            // Cortar títulos muy largos
            return item.title.length > 25 ? item.title.substring(0, 25) + '...' : item.title;
        });
        const mvData = wadChartData.most_viewed.map(item => item.views);

        if (mvData.length === 0) {
            // Mostrar un mensaje si no hay datos aún
            ctxMostViewed.style.display = 'none';
            ctxMostViewed.parentElement.innerHTML += '<p style="text-align:center; color:#646970; margin-top:50px;">Aún no hay visitas registradas. ¡Visita una de tus páginas para ver este gráfico!</p>';
        } else {
            new Chart(ctxMostViewed, {
                type: 'bar',
                data: {
                    labels: mvLabels,
                    datasets: [{
                        label: 'Visitas',
                        data: mvData,
                        backgroundColor: colors.cyan,
                        borderRadius: 4
                    }]
                },
                options: {
                    indexAxis: 'y', // Barra horizontal
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false }
                    },
                    scales: {
                        x: { beginAtZero: true, ticks: { stepSize: 1 } }
                    }
                }
            });
        }
    }

    // --- NUEVO: Gráfico de Plugins (Doughnut) ---
    const ctxPlugins = document.getElementById('pluginsStatusChart');
    const pluginListEl = document.getElementById('wadPluginList');
    if (ctxPlugins && wadChartData.plugins_data) {
        new Chart(ctxPlugins, {
            type: 'doughnut',
            data: {
                labels: ['Activos', 'Inactivos'],
                datasets: [{
                    data: [
                        wadChartData.plugins_data.active_count,
                        wadChartData.plugins_data.inactive_count
                    ],
                    backgroundColor: [colors.primary, colors.lightGray],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom' }
                }
            }
        });

        // Insertar lista de plugins
        let listHTML = '';
        wadChartData.plugins_data.list.forEach(plugin => {
            const statusClass = plugin.active ? 'wad-plugin-active' : 'wad-plugin-inactive';
            const statusText = plugin.active ? '✓ Activo' : '✗ Inactivo';
            listHTML += `
                <div class="wad-plugin-item">
                    <span>${plugin.name}</span>
                    <span class="${statusClass}">${statusText}</span>
                </div>
            `;
        });
        pluginListEl.innerHTML = listHTML;
    }


    // --- 1. Gráfico de Distribución de Contenido (Pie) ---
    const ctxContent = document.getElementById('contentDistributionChart');
    if (ctxContent) {
        new Chart(ctxContent, {
            type: 'pie',
            data: {
                labels: ['Entradas (Posts)', 'Páginas (Pages)'],
                datasets: [{
                    data: [
                        wadChartData.content_distribution.posts, 
                        wadChartData.content_distribution.pages
                    ],
                    backgroundColor: [colors.primary, colors.secondary],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom' } }
            }
        });
    }

    // --- 2. Gráfico de Estado de Comentarios (Doughnut) ---
    const ctxComments = document.getElementById('commentStatusChart');
    if (ctxComments) {
        new Chart(ctxComments, {
            type: 'doughnut',
            data: {
                labels: ['Aprobados', 'Pendientes', 'Spam'],
                datasets: [{
                    data: [
                        wadChartData.comment_status.approved,
                        wadChartData.comment_status.pending,
                        wadChartData.comment_status.spam
                    ],
                    backgroundColor: [colors.secondary, colors.warning, colors.accent],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom' } }
            }
        });
    }

    // --- 3. Gráfico de Usuarios por Rol (Bar) ---
    const ctxUsers = document.getElementById('usersByRoleChart');
    if (ctxUsers) {
        const roleLabels = Object.keys(wadChartData.users_by_role);
        const roleData = Object.values(wadChartData.users_by_role);
        
        new Chart(ctxUsers, {
            type: 'bar',
            data: {
                labels: roleLabels,
                datasets: [{
                    label: 'Usuarios',
                    data: roleData,
                    backgroundColor: colors.purple,
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
            }
        });
    }

    // --- 4. Gráfico de Publicaciones Recientes (Line) ---
    const ctxPosts = document.getElementById('recentPostsChart');
    if (ctxPosts) {
        const dates = Object.keys(wadChartData.recent_posts);
        const postCounts = Object.values(wadChartData.recent_posts);
        
        const formattedDates = dates.map(dateStr => {
            const dateObj = new Date(dateStr);
            return `${dateObj.getDate()}/${dateObj.getMonth() + 1}`;
        });

        new Chart(ctxPosts, {
            type: 'line',
            data: {
                labels: formattedDates,
                datasets: [{
                    label: 'Entradas publicadas',
                    data: postCounts,
                    borderColor: colors.primary,
                    backgroundColor: 'rgba(34, 113, 177, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'top' },
                    tooltip: {
                        callbacks: {
                            title: function(context) { return dates[context[0].dataIndex]; }
                        }
                    }
                },
                scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
            }
        });
    }

});
