<?php
// Evitar acceso directo
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Clase encargada de recolectar datos estadísticos del sitio WordPress.
 */
class WAD_Data {

    public function get_content_distribution() {
        $posts_count = wp_count_posts( 'post' );
        $pages_count = wp_count_posts( 'page' );
        
        return array(
            'posts' => isset($posts_count->publish) ? (int) $posts_count->publish : 0,
            'pages' => isset($pages_count->publish) ? (int) $pages_count->publish : 0,
        );
    }

    public function get_comment_status() {
        $comments_count = wp_count_comments();
        
        return array(
            'approved' => isset($comments_count->approved) ? (int) $comments_count->approved : 0,
            'pending'  => isset($comments_count->moderated) ? (int) $comments_count->moderated : 0,
            'spam'     => isset($comments_count->spam) ? (int) $comments_count->spam : 0,
        );
    }

    public function get_users_by_role() {
        $user_counts = count_users();
        $roles = array();
        
        if ( isset( $user_counts['avail_roles'] ) ) {
            foreach ( $user_counts['avail_roles'] as $role => $count ) {
                $role_name = ucfirst( $role );
                if ( $role === 'administrator' ) $role_name = 'Administrador';
                if ( $role === 'editor' ) $role_name = 'Editor';
                if ( $role === 'author' ) $role_name = 'Autor';
                if ( $role === 'contributor' ) $role_name = 'Colaborador';
                if ( $role === 'subscriber' ) $role_name = 'Suscriptor';

                $roles[ $role_name ] = $count;
            }
        }
        return $roles;
    }

    public function get_recent_posts_activity() {
        global $wpdb;

        $query = $wpdb->prepare(
            "SELECT DATE(post_date) as date, COUNT(ID) as count 
             FROM {$wpdb->posts} 
             WHERE post_status = 'publish' AND post_type = 'post' 
             AND post_date >= %s 
             GROUP BY DATE(post_date) 
             ORDER BY date ASC",
            date( 'Y-m-d', strtotime( '-30 days' ) )
        );

        $results = $wpdb->get_results( $query );

        $dates = array();
        for ( $i = 29; $i >= 0; $i-- ) {
            $date_string = date( 'Y-m-d', strtotime( "-$i days" ) );
            $dates[ $date_string ] = 0;
        }

        if ( $results ) {
            foreach ( $results as $row ) {
                if ( isset( $dates[ $row->date ] ) ) {
                    $dates[ $row->date ] = (int) $row->count;
                }
            }
        }

        return $dates;
    }

    /**
     * Obtiene el total de visitas de todo el sitio sumando los meta_keys
     */
    public function get_total_views() {
        global $wpdb;
        $total = $wpdb->get_var( "SELECT SUM(meta_value) FROM $wpdb->postmeta WHERE meta_key = '_wad_view_count'" );
        return $total ? (int) $total : 0;
    }

    /**
     * Obtiene las páginas o entradas con más visitas
     */
    public function get_most_viewed_posts( $limit = 5 ) {
        $args = array(
            'post_type'      => array( 'post', 'page' ),
            'post_status'    => 'publish',
            'posts_per_page' => $limit,
            'meta_key'       => '_wad_view_count',
            'orderby'        => 'meta_value_num',
            'order'          => 'DESC',
            'fields'         => 'ids' // Solo obtener IDs por eficiencia
        );
        
        $query = new WP_Query( $args );
        $most_viewed = array();
        
        if ( $query->have_posts() ) {
            foreach ( $query->posts as $post_id ) {
                $most_viewed[] = array(
                    'title' => get_the_title( $post_id ),
                    'views' => (int) get_post_meta( $post_id, '_wad_view_count', true )
                );
            }
        }
        
        return $most_viewed;
    }

    /**
     * Obtiene los plugins instalados y sus estados
     */
    public function get_plugins_data() {
        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        
        $all_plugins = get_plugins();
        $active_plugins = get_option( 'active_plugins', array() );
        
        $data = array(
            'active_count'   => 0,
            'inactive_count' => 0,
            'list'           => array()
        );
        
        foreach ( $all_plugins as $plugin_path => $plugin_info ) {
            $is_active = in_array( $plugin_path, $active_plugins );
            
            if ( $is_active ) {
                $data['active_count']++;
            } else {
                $data['inactive_count']++;
            }
            
            $data['list'][] = array(
                'name'   => $plugin_info['Name'],
                'active' => $is_active
            );
        }
        
        return $data;
    }
}
