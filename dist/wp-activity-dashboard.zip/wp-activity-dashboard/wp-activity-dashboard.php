<?php
/**
 * Plugin Name: WP Activity Dashboard
 * Plugin URI:  https://tusitio.com/
 * Description: Un panel de control elegante para visualizar las estadísticas de tu sitio WordPress con gráficos interactivos.
 * Version:     2.0.0
 * Author:      Ingeniero de Datos (Tú)
 * Author URI:  https://tusitio.com/
 * Text Domain: wp-activity-dashboard
 */

// Evitar acceso directo
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Definir constantes del plugin
define( 'WAD_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WAD_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
// Nombre de la tabla personalizada para almacenar visitas diarias
define( 'WAD_TABLE_DAILY_VIEWS', $wpdb->prefix . 'wad_daily_views' );

// Crear tabla al activar el plugin
function wad_activate() {
    global $wpdb;
    $table_name = WAD_TABLE_DAILY_VIEWS;
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (\n        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,\n        post_id BIGINT(20) UNSIGNED NOT NULL,\n        view_date DATE NOT NULL,\n        views BIGINT(20) UNSIGNED NOT NULL DEFAULT 1,\n        PRIMARY KEY  (id),\n        UNIQUE KEY post_date (post_id, view_date)\n    ) $charset_collate;";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql );
}
register_activation_hook( __FILE__, 'wad_activate' );

// Función para registrar visitas únicas basadas en cookies
function wad_track_post_views() {
    if ( is_admin() || ! is_singular() || is_preview() ) {
        return;
    }
    global $post, $wpdb;
    if ( ! $post ) {
        return;
    }
    $post_id = $post->ID;
    $meta_key = '_wad_view_count';
    // ---- Contador total (páginas vistas) ----
    $views = get_post_meta( $post_id, $meta_key, true );
    if ( $views === '' ) {
        $views = 0;
    }
    $views++;
    update_post_meta( $post_id, $meta_key, $views );

    // ---- Contador único (por visitante) ----
    $cookie_name = 'wad_viewed_' . $post_id;
    if ( ! isset( $_COOKIE[ $cookie_name ] ) ) {
        // Primera visita del usuario a este post en los últimos 24h
        setcookie( $cookie_name, '1', time() + DAY_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN );
        // Guardar en tabla diaria
        $today = current_time( 'Y-m-d' );
        $table = WAD_TABLE_DAILY_VIEWS;
        $wpdb->query( $wpdb->prepare(
            "INSERT INTO $table (post_id, view_date, views) VALUES (%d, %s, 1) ON DUPLICATE KEY UPDATE views = views + 1",
            $post_id,
            $today
        ) );
    }
}
add_action( 'wp', 'wad_track_post_views' );


// Incluir la clase de datos
require_once WAD_PLUGIN_DIR . 'includes/class-wad-data.php';

/**
 * Registrar visitas en las páginas y entradas individuales
 */
function wad_track_post_views() {
    // Si no es una entrada o página individual, es el panel de admin, o es una vista previa, salir
    if ( is_admin() || ! is_singular() || is_preview() ) {
        return;
    }

    global $post;
    if ( ! $post ) {
        return;
    }

    $post_id = $post->ID;
    $meta_key = '_wad_view_count';
    
    // Obtener visitas actuales
    $views = get_post_meta( $post_id, $meta_key, true );
    if ( $views === '' ) {
        $views = 0;
        delete_post_meta( $post_id, $meta_key );
        add_post_meta( $post_id, $meta_key, '1' );
    } else {
        $views++;
        update_post_meta( $post_id, $meta_key, $views );
    }
}
add_action( 'wp', 'wad_track_post_views' );

/**
 * Registrar la página de menú en el admin de WordPress
 */
function wad_register_admin_menu() {
    add_menu_page(
        'Activity Dashboard',           // Título de la página
        'Panel de Actividad',           // Título del menú
        'manage_options',               // Capacidad requerida
        'wp-activity-dashboard',        // Slug del menú
        'wad_render_dashboard_page',    // Función que renderiza el HTML
        'dashicons-chart-area',         // Icono (Dashicon)
        30                              // Posición en el menú
    );
}
add_action( 'admin_menu', 'wad_register_admin_menu' );

/**
 * Encolar scripts y estilos solo en la página del plugin
 */
// Encolar scripts y estilos solo en la página del plugin
function wad_enqueue_admin_scripts( $hook ) {
    // Comprobar que estamos en la página correcta
    if ( $hook !== 'toplevel_page_wp-activity-dashboard' ) {
        return;
    }

    // Estilos del dashboard
    wp_enqueue_style( 'wad-dashboard-style', WAD_PLUGIN_URL . 'assets/css/dashboard-style.css', array(), '2.0.0' );

    // Chart.js desde CDN (versión 3.9.1 es muy estable)
    wp_enqueue_script( 'chartjs', 'https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js', array(), null, true );

    // Nuestro script para inicializar los gráficos
    wp_enqueue_script( 'wad-dashboard-charts', WAD_PLUGIN_URL . 'assets/js/dashboard-charts.js', array('chartjs'), '2.0.0', true );

    // Obtener los datos reales de WP usando nuestra clase
    $wad_data = new WAD_Data();
    $chart_data = array(
        'content_distribution' => $wad_data->get_content_distribution(),
        'comment_status'       => $wad_data->get_comment_status(),
        'users_by_role'        => $wad_data->get_users_by_role(),
        'recent_posts'         => $wad_data->get_recent_posts_activity(),
        'total_views'          => $wad_data->get_total_views(),
        'most_viewed'          => $wad_data->get_most_viewed_posts(),
        'plugins_data'         => $wad_data->get_plugins_data(),
        // Nuevos datos de visitas únicas diarias (últimos 30 días)
        'daily_unique_views'   => $wad_data->get_daily_unique_views(30)
    );

    // Pasar los datos de PHP a JavaScript
    wp_localize_script( 'wad-dashboard-charts', 'wadChartData', $chart_data );
}
add_action( 'admin_enqueue_scripts', 'wad_enqueue_admin_scripts' );

add_action( 'admin_enqueue_scripts', 'wad_enqueue_admin_scripts' );

/**
 * Renderizar el HTML de la página del panel
 */
function wad_render_dashboard_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    ?>
    <div class="wrap wad-wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        <p class="wad-description">Resumen visual de toda la actividad importante de tu sitio WordPress.</p>
        
        <div class="wad-grid">
            
            <!-- Tarjeta Nueva: Resumen de Visitas (KPI) -->
            <div class="wad-card wad-kpi-card">
                <h2>Visitas Totales</h2>
                <div class="wad-kpi-value" id="wadTotalViews">0</div>
                <p class="wad-kpi-desc">Páginas y Entradas vistas desde la instalación</p>
            </div>

            <!-- Tarjeta Nueva: Páginas más vistas -->
            <div class="wad-card">
                <h2>Top 5 Contenidos Más Vistos</h2>
                <div class="wad-chart-container">
                    <canvas id="mostViewedChart" aria-label="Gráfico de entradas más vistas" role="img"></canvas>
                </div>
            </div>

            <!-- Tarjeta 1: Distribución de Contenido -->
            <div class="wad-card">
                <h2>Distribución de Contenido</h2>
                <div class="wad-chart-container">
                    <canvas id="contentDistributionChart" aria-label="Gráfico de distribución de contenido" role="img"></canvas>
                </div>
            </div>

            <!-- Tarjeta 2: Estado de Comentarios -->
            <div class="wad-card">
                <h2>Estado de los Comentarios</h2>
                <div class="wad-chart-container">
                    <canvas id="commentStatusChart" aria-label="Gráfico de estado de comentarios" role="img"></canvas>
                </div>
            </div>

            <!-- Tarjeta Nueva: Plugins Utilizados -->
            <div class="wad-card">
                <h2>Estado de Plugins</h2>
                <div class="wad-chart-container">
                    <canvas id="pluginsStatusChart" aria-label="Gráfico de estado de plugins" role="img"></canvas>
                </div>
                <!-- Aquí JavaScript insertará la lista en texto -->
                <div class="wad-plugin-list" id="wadPluginList"></div>
            </div>

            <!-- Tarjeta 3: Usuarios por Rol -->
            <div class="wad-card">
                <h2>Usuarios por Rol</h2>
                <div class="wad-chart-container">
                    <canvas id="usersByRoleChart" aria-label="Gráfico de usuarios por rol" role="img"></canvas>
                </div>
            </div>

            <!-- Tarjeta 4: Publicaciones en los últimos 30 días -->
            <div class="wad-card wad-card-wide">
                <h2>Actividad de Publicaciones (Últimos 30 días)</h2>
                <div class="wad-chart-container wad-chart-container-large">
                    <canvas id="recentPostsChart" aria-label="Gráfico de publicaciones recientes" role="img"></canvas>
                </div>
            </div>
        </div>
    </div>
    <?php
}
